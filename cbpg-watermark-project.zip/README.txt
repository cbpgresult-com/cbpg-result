Upload your CBPG logo as po.jpg in this folder before deploying to Render.
